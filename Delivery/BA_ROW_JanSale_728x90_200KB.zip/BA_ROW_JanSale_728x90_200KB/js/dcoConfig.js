/*
* SET STUDIO PROFILE ID AND CAMPAIGN FEED NAME
*/

// the dynamic profile ID
Enabler.setProfileId(10587883);

// the name of the feed. The is a concatenation of the ingested feed name and tab name
var _feedName = "205307132_BA_ROW_Jan_Sale_2021_All_Sizes";